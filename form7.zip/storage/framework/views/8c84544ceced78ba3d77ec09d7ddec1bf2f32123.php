<style>
    .pt-100 {
        padding-top:200px;

    }
</style>

<?php if($page == 10 || $page == 11 ): ?>
<div class="pt-100"></div>
<?php endif; ?>
    <div class="row  m-0">
        <div class="border border-dark small_text mb-2">
            <div><b>ADA Notice: </b>The Maine Judicial Branch complies with the Americans with Disabilities Act (ADA). If you need a reasonable</div>
            <div>accommodation contact the Court Access Coordinator, <a href="#">accessibility@courts.maine.gov</a>, or a court clerk.</div>
            <div><b>Language Services:</b> For language assistance and interpreters, contact a court clerk or <a  >interpreters@courts.maine.gov.</a></div>
        </div>
        <div class="col-lg-4  mt-3 mt-lg-0 small_text text-dark fw-bold ">
            <div class=""  >
            <div>FM-043, Rev. 01/21</div>
            <div>Financial Statement</div>
            </div>
        </div>
        <div class="col-lg-4  mt-3 mt-lg-0 text-center mx-auto">
            Page <?php echo e($page); ?> of 11
            
        </div>
        <div class="col-lg-4 my-3 my-lg-0 text-center mx-auto">
            <a href="https://www.courts.maine.gov/" target="_blank">www.courts.maine.gov</a>
        </div>
    </div>

<?php /**PATH /Users/vishnu/Desktop/projects/marland_new/new/maryland/resources/views/layouts/footer18.blade.php ENDPATH**/ ?>