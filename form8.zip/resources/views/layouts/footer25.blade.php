<style>
    .pt-300 {
        padding-top:300px;

    }
</style>


    <div class="row  m-0 ">

        <div class="col-lg-10  mt-3 mt-lg-0  ">
            <div>© Form Approved by the Supreme Court of Texas by order in Misc. Docket No. 13-9085 (June 17, 2013)
                Petition for Divorce (Divorce Set 1 - Uncontested, No Minor Children, No Real Property)</div>
        </div>
        <div class="col-lg-2 my-3 my-lg-0 text-center mx-auto">
            <div>Page {{$page}} of 5  </div>
        </div>
    </div>


