<style>
    .pt-100 {
        padding-top:200px;

    }
</style>

<?php if($page == 5): ?>
<div class="pt-100"></div>
<?php endif; ?>
    <div class="row  m-0 pt-3">

        <div class="col-lg-4  mt-3 mt-lg-0 small_text text-dark fw-bold ">

            <div>NHJB-2065-F (06/15/2020</div>

        </div>
        <div class="col-lg-4  mt-3 mt-lg-0 text-center mx-auto">
            Page <?php echo e($page); ?> of 11
            
        </div>
        <div class="col-lg-4 my-3 my-lg-0 text-center mx-auto">
            <button > <a href="#" class="text-dark text-decoration-none">Top of Page</a></button>
        </div>
    </div>

<?php /**PATH /Users/vishnu/Desktop/projects/marland_new/new/maryland/resources/views/layouts/footer19.blade.php ENDPATH**/ ?>