<div class="row">
    <div class="small_text"> <span class="me-lg-5 me-2"><input type="checkbox" name="dspv_{{$page}}" id=""> AOC-238 Doc. Code DSPV	 </span>	<span class="ms-lg-5 ms-2"><input type="checkbox" name="dsfv_{{$page}}" id=""> AOC-239 Doc. Code DSFV</span></div>
    <div class="small_text d-flex d_sm_block justify-content-between">
        <div>Rev. 1-15</div>
        <div>Disclosure of<input type="text" name="disclosure_page_{{$page}}" id="" class=" border-0 border-bottom responsive_input" style="width:220px;"></div>
    </div>
    <div class="small_text d-flex d_sm_block justify-content-between">
        <div>Page {{$page}} of 10 </div>
        <div>Case No.<input type="text" name="case_number_page_{{$page}}" id="" class=" border-0 border-bottom responsive_input" style="width:250px;"></div>
    </div>
    <div class="small_text">  </div>
</div>
