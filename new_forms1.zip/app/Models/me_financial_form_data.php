<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class me_financial_form_data extends Model
{
    use HasFactory;

     protected $table =  "24_me_financial_form_datas";
    protected $guarded = [];

}
