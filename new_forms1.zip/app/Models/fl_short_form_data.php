<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class fl_short_form_data extends Model
{
    use HasFactory;
    protected $table = "17_fl_short_form_datas";

    protected $guarded = [];
}
