

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <div class="row mx-auto text-center mt-5">
            <div class="col-lg-4 mt-4 mt-lg-0">
                <a href="<?php echo e(route('form.index')); ?>" class="text-decoration-none">
                <div class="card">
                     <div class="card-body p-5 ">
                      <h5 class="text-decoration-none text-dark">Form 1</h5>
                      <span>MD.pdf</span>

                    </div>
                  </div>
                </a>
            </div>
            <div class="col-lg-4 mt-4 mt-lg-0">
                <a href="<?php echo e(route('pdf_form2')); ?>" class="text-decoration-none">

                <div class="card">
                     <div class="card-body p-5 ">
                      <h5 class="text-decoration-none text-dark">Form 2</h5>
                      <span>MD partially filled out to check formulas.pdf</span>

                    </div>
                  </div>
                </a>
            </div>
            <div class="col-lg-4 mt-4 mt-lg-0">
                <a href="<?php echo e(route('pdf_form3')); ?>" class="text-decoration-none">

                <div class="card">
                     <div class="card-body p-5">
                      <h5 class="text-decoration-none text-dark">Form 3</h5>
                      <span>domestic-relations-financial-affidavit_type-in-form GA.pdf</span>

                    </div>
                  </div>
                </a>
            </div>
            <div class="col-lg-4 mt-4 mt-lg-0">
                <a href="<?php echo e(route('pdf_form4')); ?>" class="text-decoration-none">

                <div class="card">
                     <div class="card-body p-5">
                      <h5 class="text-decoration-none text-dark">Form 4</h5>
                      <span>rev-488 PA.pdf</span>

                    </div>
                  </div>
                </a>
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH /Users/vishnu/Desktop/projects/form/resources/views/welcome.blade.php ENDPATH**/ ?>