  <div class="row py-5">
  <h6 class="<?php echo e($page == 7 ? 'col':'col-lg-4 col-4 '); ?>" class=>CC-DR-031 (Rev. 12/2023) </h6>
    <div class="<?php echo e($page == 7 ? 'col':'col-lg-4 col-4 '); ?> text-center"> Page <?php echo e($page); ?> of 7</div>

    <?php if($page == 7 ): ?>
    <div class="col">

        <button type="submit" class="bg-transparent px-4">Submit</button>
    </div>
    <div class="col">

        <button type="reset" class="bg-transparent px-4">Reset</button>
    </div>

    <?php endif; ?>
     <h5 class="<?php echo e($page == 7 ? 'col':'col-lg-4 col-4   '); ?> text-center">FISTA</h5>

  </div>
<?php /**PATH /Users/vishnu/Desktop/projects/form/resources/views/layouts/footer.blade.php ENDPATH**/ ?>