  <div class="row pt-5">
  <div class="<?php echo e($page == 7 ? 'col':'col-sm-4'); ?>">CC-DR-031 (Rev. 12/2023) </div>
    <div class="<?php echo e($page == 7 ? 'col':'col-sm-4'); ?> text-center"> Page <?php echo e($page); ?> of 7</div>

    <?php if($page == 7 ): ?>
    <div class="col">

        <button type="submit" class="bg-transparent px-4">Submit</button>
    </div>
    <div class="col">

        <button type="reset" class="bg-transparent px-4">Reset</button>
    </div>

    <?php endif; ?>
     <div class="<?php echo e($page == 7 ? 'col':'col-sm-4'); ?> text-center">FISTA</div>

  </div>
<?php /**PATH /Users/vishnu/Desktop/projects/form/resources/views/layouts/footer.blade.php ENDPATH**/ ?>