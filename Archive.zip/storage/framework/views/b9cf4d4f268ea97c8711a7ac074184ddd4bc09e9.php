<div class=" mx-auto text-center  py-5">

    <?php if($page == 9 ): ?>
    <div class="footer_padding"></div>
    <?php endif; ?>
    <h6 class="<?php echo e($page == 9 ? 'col-':' '); ?>"  >Pataula Judicial Circuit </h6>
    <h6 class="<?php echo e($page == 9 ? 'col-':' '); ?>"  ><span class="fw-bold h5"> Domestic Relations Financial Affidavit </span> - Revised 2016 </h6>
      <div class="<?php echo e($page == 9 ? 'col-':'c '); ?> text-center"> Page <?php echo e($page); ?> of 9</div>

      <?php if($page == 9 ): ?>
       <div class="col d-flex justify-content-center mt-3">

          <button type="button" class="bg-transparent px-4 me-4">Submit</button>
          <button type="reset" class="bg-transparent px-4">Reset</button>

      </div>
      <div class="   mt-4">

      </div>

      <?php endif; ?>

    </div>
<?php /**PATH /Users/vishnu/Desktop/projects/marland_new/new/maryland/resources/views/layouts/footer2.blade.php ENDPATH**/ ?>