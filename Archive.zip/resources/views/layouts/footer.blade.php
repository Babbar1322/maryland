  <div class="row pt-5">
  <div class="{{$page == 7 ? 'col':'col-sm-4'}}">CC-DR-031 (Rev. 12/2023) </div>
    <div class="{{$page == 7 ? 'col':'col-sm-4'}} text-center"> Page {{$page}} of 7</div>

    @if($page == 7 )
    <div class="col">

        <button type="submit" class="bg-transparent px-4">Submit</button>
    </div>
    <div class="col">

        <button type="reset" class="bg-transparent px-4">Reset</button>
    </div>

    @endif
     <div class="{{$page == 7 ? 'col':'col-sm-4'}} text-center">FISTA</div>

  </div>
