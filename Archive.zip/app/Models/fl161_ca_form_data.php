<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class fl161_ca_form_data extends Model
{
    use HasFactory;
    protected $table = "fl161_ca_form_datas";

    protected $guarded = [];
}
