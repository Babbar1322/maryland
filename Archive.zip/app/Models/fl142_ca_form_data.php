<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class fl142_ca_form_data extends Model
{
    use HasFactory;

    protected $guarded = [];
}
