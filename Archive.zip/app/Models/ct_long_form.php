<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ct_long_form extends Model
{
    use HasFactory;
    protected $table = "ct_long_forms";

    protected $guarded = [];
}
