<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class fl160_ca_form extends Model
{
    use HasFactory;
    protected $table = "fl160_ca_forms";

    protected $guarded = [];
}
