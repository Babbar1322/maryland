<style>
    .pt-100 {
        padding-top:200px;

    }
</style>

<?php if($page == 2): ?>
<div class="pt-100"></div>
<?php endif; ?>
    <div class="row  m-0 pt-3">
        <div class="col-lg-4  mt-3 mt-lg-0 small_text text-dark fw-bold ">
            <div>CJ-D 301 Schedule A (4/07)</div>
        </div>
        <div class="col-lg-4  mt-3 mt-lg-0 text-center mx-auto">
            Page <?php echo e($page); ?> of 2
        </div>
        <div class="col-lg-4 my-3 my-lg-0 text-center mx-auto">
            <div>CGF</div>
        </div>
    </div>

<?php /**PATH /Users/vishnu/Desktop/projects/marland_new/new/maryland/resources/views/layouts/footer20.blade.php ENDPATH**/ ?>