<style>
    .pt-300 {
        padding-top:300px;

    }
</style>

<?php if($page == 9 || $page == 6): ?>
<div class="pt-300"></div>
<?php endif; ?>
    <div class="row  m-0 pt-3">
        <div class="col-lg-4  mt-3 mt-lg-0 small_text text-dark fw-bold ">
            <div>CJ-D 301 L 9/15/17</div>
        </div>
        <div class="col-lg-4  mt-3 mt-lg-0 text-center mx-auto">
            Page <?php echo e($page); ?> of 9
        </div>
        <div class="col-lg-4 my-3 my-lg-0 text-center mx-auto">
            <div>C.G.F.</div>
        </div>
    </div>

<?php /**PATH /Users/vishnu/Desktop/projects/marland_new/new/maryland/resources/views/layouts/footer22.blade.php ENDPATH**/ ?>