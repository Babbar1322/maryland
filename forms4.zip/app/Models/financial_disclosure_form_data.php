<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class financial_disclosure_form_data extends Model
{
    use HasFactory;
    protected $table = "19_financial_disclosure_form_datas";

    protected $guarded = [];
}
