<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class nj_form_data extends Model
{
    use HasFactory;
    protected $table = "5_nj_form_data";

    protected $guarded = [];
}
