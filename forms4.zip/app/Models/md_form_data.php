<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class md_form_data extends Model
{
    use HasFactory;
    protected $table = "1_md_form_datas";

    protected $guarded = [];
}
