<style>
    .pt-300 {
        padding-top:300px;

    }
</style>

<?php if( $page == 6): ?>
 <?php endif; ?>
    <div class="row  m-0 ">
        <div class="col-lg-4  mt-3 mt-lg-0 small_text text-dark fw-bold ">
            <div>Courtesy of MY Statement of Net Worth</div>
        </div>
        <div class="col-lg-4  mt-3 mt-lg-0 text-center mx-auto">
            <a href="">https://www.MYstatementofnetworth.com</a>
        </div>
        <div class="col-lg-4 my-3 my-lg-0 text-center mx-auto">
            <div>Page <?php echo e($page); ?> of 10</div>
        </div>
    </div>

<?php /**PATH /Users/vishnu/Desktop/projects/marland_new/new/maryland/resources/views/layouts/footer23.blade.php ENDPATH**/ ?>