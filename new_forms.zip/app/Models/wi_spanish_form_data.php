<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class wi_spanish_form_data extends Model
{
    use HasFactory;
    protected $table = "22_wi_spanish_form_datas";

    protected $guarded = [];

}
