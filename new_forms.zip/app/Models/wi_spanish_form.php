<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class wi_spanish_form extends Model
{
    use HasFactory;

    protected $table = "22_wi_spanish_forms";

    protected $guarded = [];
}
