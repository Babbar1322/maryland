<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class financial_disclosure_form extends Model
{
    use HasFactory;
    protected $table = "19_financial_disclosure_forms";

    protected $guarded = [];
}
