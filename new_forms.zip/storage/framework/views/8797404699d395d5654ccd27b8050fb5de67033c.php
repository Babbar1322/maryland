<style>
    .break-spaces {
    white-space: break-spaces !important;
}
</style>



<?php /**PATH /Users/vishnu/Desktop/projects/marland_new/new/maryland/resources/views/layouts/pagination.blade.php ENDPATH**/ ?>