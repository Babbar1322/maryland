<div class="row pb-5 pt-3 ">
    {{-- <div class="{{$page == 15 ? 'col-sm-9':'col-lg-12 '}}"  >
        Instructions for Florida Family Law Rules of Procedure Form 12.902(c), Family Law Financial Affidavit (Long Form)
        (10/21)</div> --}}
      <div class="{{$page == 10 ? 'col-lg-6':'col-lg-6  '}}"> FA-4139V, 12/22 Financial Disclosure Statement</div>
      <div class="{{$page == 10 ? 'col-lg-6':'col-lg-6  '}} text-end" > §767.127, Wisconsin Statutes</div>
      <div class="text-center fw-bold">
          This form shall not be modified. It may be supplemented with additional material.
        </div>

        <div class=" text-center"> Page {{$page}} of 10</div>
      @if($page == 10 )
      {{-- <div class="col-lg-2 col-6 mx-auto ">
          <button type="submit" class="bg-transparent px-4">Submit</button>
      </div> --}}
      <div class="col-lg-1 col-6  mx-auto mt-lg-0  ">

          <button type="reset" class="bg-transparent px-4">Reset</button>
      </div>

      @endif

    </div>





