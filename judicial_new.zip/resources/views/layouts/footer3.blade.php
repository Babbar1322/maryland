<div class="row  text-center  ">
    <div class="col-lg-2 col  mx-auto px-0 mx-0 bg-danger my-auto text-white" style="min-width:150px;"> Reset Entrie Form </div>
    <div class="col-lg-2  col mx-auto text-danger my-auto small_text"  >TOP OF PAGE </div>
    <div class="col-lg-2 col  mx-auto text-center my-auto"> <h3> Page {{$page}} </h3></div>
    <div class="col-lg-2 col  mx-auto text-danger  my-auto small_text">NEXT PAGE </div>
    <div class="col-lg-2 col  mx-auto text-white my-auto bg-primary" style="width:100px;" onclick="window.print()">Print</div>
    @if($page == 6 )

    <div class="col-lg-2 col">
        <button type="submit" class="bg-transparent">Submit</button>
     </div>
    @endif
</div>
