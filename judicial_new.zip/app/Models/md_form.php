<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class md_form extends Model
{
    use HasFactory;
    protected $table = "1_md_forms";

    protected $guarded = [];
}
