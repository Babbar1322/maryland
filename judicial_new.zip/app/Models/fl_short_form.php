<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class fl_short_form extends Model
{
    use HasFactory;
    protected $table = "17_fl_short_forms";

    protected $guarded = [];
}
