<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class fl150_ca_form extends Model
{
    use HasFactory;
    protected $guarded = [];
    protected $table = "14_fl150_ca_forms";
}
