<div class="row  d-flex justify-content-around  py-5">
    <?php if($page == 8 || $page == 7 ): ?>
        <div class="footer_padding"></div>
    <?php endif; ?>
     <div class="<?php echo e($page == 8 ? 'col-lg-3 text-center':'col-lg-3 text-end  text-center'); ?>"> Page <?php echo e($page); ?> of 8</div>


    <?php if($page == 8 ): ?>
    <div class="col col- d-flex justify-content-center mt-3">
       <button type="submit" class="bg-transparent px-4 me-4">Submit</button>
       <button type="reset" class="bg-transparent px-4">Reset</button>
   </div>
</div>
   <?php endif; ?>
<?php /**PATH /Users/vishnu/Desktop/projects/marland_new/new/maryland/resources/views/layouts/footer14.blade.php ENDPATH**/ ?>