<div class="row py-5">
    <div class="<?php echo e($page == 6 ? 'col-sm-6':'col-lg-6  '); ?>"  >JDF 1111 R7/06 SWORN FINANCIAL STATEMENT – FORM 35.2</div>
      <div class="<?php echo e($page == 6 ? 'col-lg-3':'col-lg-4  '); ?> text-center"> Page <?php echo e($page); ?> of 6</div>

      <?php if($page == 6 ): ?>
      <div class="col-lg-2 ">

          <button type="submit" class="bg-transparent px-4">Submit</button>
      </div>
      <div class="col-lg-1  mt-lg-0 mt-4">

          <button type="reset" class="bg-transparent px-4">Reset</button>
      </div>

      <?php endif; ?>

    </div>

<?php /**PATH /Users/vishnu/Desktop/projects/marland_new/new/maryland/resources/views/layouts/footer11.blade.php ENDPATH**/ ?>