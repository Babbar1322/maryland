<!-- resources/views/layouts/app.blade.php -->

<!DOCTYPE html>
<html>
<head>
    <title>Laravel Dropdown Routes</title>
    <!-- Add your CSS and JS files here -->
</head>
<body>
    <div>
        <?php
            $routes = [
                'pdf name' => route('pdf_form2'),
                'dfa 2' => route('pdf_form3'),
                'fdafd 3' => route('pdf_form4'),
                'af 4' => route('pdf_form5'),
            ];
        ?>

        <select id="routeDropdown" onchange="location = this.value;">
            <option value="" disabled selected>Select a route</option>
            <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($url); ?>"><?php echo e($name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
</html>
<?php /**PATH /Users/vishnu/Desktop/projects/marland_new/new/maryland/resources/views/layouts/app.blade.php ENDPATH**/ ?>