<div class="row pb-5 pt-3">
    <div class="{{$page == 15 ? 'col-sm-9':'col-lg-12 '}}"  >
        Instructions for Florida Family Law Rules of Procedure Form 12.902(c), Family Law Financial Affidavit (Long Form)
        (10/21)</div>
      {{-- <div class="{{$page == 6 ? 'col-lg-3':'col-lg-4  '}} text-center"> Page {{$page}} of 6</div> --}}

      @if($page == 15 )
      <div class="col-lg-2 ">
          <button type="submit" class="bg-transparent px-4">Submit</button>
      </div>
      <div class="col-lg-1  mt-lg-0 mt-4">

          <button type="reset" class="bg-transparent px-4">Reset</button>
      </div>

      @endif

    </div>





