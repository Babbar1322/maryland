<div class="row  d-flex justify-content-around  py-5">
    <?php if($page == 10 ): ?>
        <div class="footer_padding"></div>
    <?php endif; ?>
    <h6 class="<?php echo e($page == 10 ? 'col-lg-9':' col-lg-9'); ?>"  ><span class="fw-bold h5"> Revised to be effective September 1, 2017. CN: 10482 (Court Rules Appendix V)</h6>
    <div class="<?php echo e($page == 10 ? 'col-lg-3':'col-lg-3 text-end'); ?>"> Page <?php echo e($page); ?> of 10</div>
    </div>

    <?php if($page == 10 ): ?>
    <div class="col d-flex justify-content-center mt-3">
       
       <button type="reset" class="bg-transparent px-4">Reset</button>
   </div>
   <?php endif; ?>
<?php /**PATH /Users/vishnu/Desktop/projects/marland_new/new/maryland/resources/views/layouts/footer4.blade.php ENDPATH**/ ?>