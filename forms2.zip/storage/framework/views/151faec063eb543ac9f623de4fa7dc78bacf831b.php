<div class="row my-5 pt-1 border-top border-dark">
        <h6 class="<?php echo e($page == 14 ? 'col':'col-lg-4 col-4 '); ?>"  >
        <div>1352FAJ Approved February 25, 2019</div>
        <div>/ Revised November 21, 2022</div>  </h6>
      <div class="<?php echo e($page == 14 ? 'col':'col-lg-4 col-4 '); ?> text-center fw-bold">Financial Declaration</div>
      <?php if($page == 14 ): ?>
        
        <div class="col">
            <button type="reset" class="bg-transparent px-4">Reset</button>
        </div>
      <?php endif; ?>
       <h5 class="<?php echo e($page == 14 ? 'col':'col-lg-4 col-4   '); ?> text-center"> Page <?php echo e($page); ?> of 14</h5>
<?php /**PATH /Users/vishnu/Desktop/projects/marland_new/new/maryland/resources/views/layouts/footer15.blade.php ENDPATH**/ ?>