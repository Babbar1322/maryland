<div class="row pb-5 pt-3">
    <div class="<?php echo e($page == 15 ? 'col-sm-9':'col-lg-12 '); ?>"  >
        Instructions for Florida Family Law Rules of Procedure Form 12.902(c), Family Law Financial Affidavit (Long Form)
        (10/21)</div>
      

      <?php if($page == 15 ): ?>
      
      <div class="col-lg-1  col-6 pt-lg-0 pt-3 ">

          <button type="reset" class="bg-transparent px-4">Reset</button>
      </div>

      <?php endif; ?>

    </div>





<?php /**PATH /Users/vishnu/Desktop/projects/marland_new/new/maryland/resources/views/layouts/footer12.blade.php ENDPATH**/ ?>