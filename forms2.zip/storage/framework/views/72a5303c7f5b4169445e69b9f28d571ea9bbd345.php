<div class="row pb-5 pt-3 ">
    
      <div class="<?php echo e($page == 10 ? 'col-lg-6':'col-lg-6  '); ?>"> FA-4139V, 12/22 Financial Disclosure Statement</div>
      <div class="<?php echo e($page == 10 ? 'col-lg-6':'col-lg-6  '); ?> text-end" > §767.127, Wisconsin Statutes</div>
      <div class="text-center fw-bold">
          This form shall not be modified. It may be supplemented with additional material.
        </div>

        <div class=" text-center"> Page <?php echo e($page); ?> of 10</div>
      <?php if($page == 10 ): ?>
      
      <div class="col-lg-1 col-6  mx-auto mt-lg-0  ">

          <button type="reset" class="bg-transparent px-4">Reset</button>
      </div>

      <?php endif; ?>

    </div>





<?php /**PATH /Users/vishnu/Desktop/projects/marland_new/new/maryland/resources/views/layouts/footer17.blade.php ENDPATH**/ ?>