<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class fa_4139_form_data extends Model
{
    use HasFactory;

    protected $guarded = [];
    protected $table = "21_fa_4139_form_datas";
}
