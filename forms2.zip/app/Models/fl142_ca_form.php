<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class fl142_ca_form extends Model
{
    use HasFactory;

    protected $guarded = [];
    protected $table = "13_fl142_ca_forms";

}
