<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class sfs_co_form_data extends Model
{
    use HasFactory;

    protected $table = "15_sfs_co_form_datas";
     protected $guarded = [];
}
